from services.google_calendar_api import get_today_events

print(get_today_events())
