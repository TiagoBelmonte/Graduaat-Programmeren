from utils.nlp_utils import detect_email_question

print(detect_email_question("kun je in mijn inbox zoeken naar mails met open Ai"))
print(detect_email_question("toon mijn mails over stage"))
print(detect_email_question("geef mijn e-mails met als onderwerp Prompto"))

