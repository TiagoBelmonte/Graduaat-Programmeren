Een visuele chatbot-applicatie in Python, waarmee je:

In natuurlijke taal kan communiceren via tekst (optioneel spraak via microfoon)

Het weer kan opvragen via stad of GPS

Topnieuws van de dag kan opvragen

Google Calendar-afspraken voor vandaag kan tonen

Gewone vragen kan stellen (zoals bij ChatGPT of Ollama)

🧠 Chatbot = eenvoudige integratie met een LLM (zoals GPT-3.5)
📱 UI = via Tkinter of eventueel PyQt (grafische interface in Python)
